package com.linecorp.linesdk.unitywrapper.model


data class Error(
    val code: Int,
    val message: String
)
