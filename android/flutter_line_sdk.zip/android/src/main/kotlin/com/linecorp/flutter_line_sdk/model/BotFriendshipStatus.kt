package com.linecorp.linesdk.unitywrapper.model


data class BotFriendshipStatus(val friendFlag: Boolean)
